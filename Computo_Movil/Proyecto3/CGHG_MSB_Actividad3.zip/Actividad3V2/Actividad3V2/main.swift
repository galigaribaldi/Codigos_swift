//
//  main.swift
//  Actividad3V2
// Clase Producto
import Foundation


class Client{
  static func start(){
    Facade.serve()
  }
}
Client.start()
